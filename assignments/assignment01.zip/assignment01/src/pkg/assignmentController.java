package pkg;

public class assignmentController {
	private assignment model;
	private assignmentView view;
	
	public assignmentController(assignment model, assignmentView view){
		this.model = model;
		this.view = view;
	}
	
	public void setArray() {
		model.setArr(view.vSetArr());
	}
	
	public void updateView() {
		view.printArray(model.getArray());
	}
	
	public void sortArray() {
		model.bubbleSort();
	}
	
	public void searchValue() {
		int key = view.setKey();
		view.vSearchValue(model.linearSearch(key));
	}
}
