package pkg;

public class assignment {
	private int[] arr;
	
	public assignment() {
		arr = new int[5];
	}
	
	public void bubbleSort() {
		int n = arr.length;
		int temp = 0;

		for(int i=0; i < n; i++){
			for(int j=1; j < (n-i); j++){
				if(arr[j-1] > arr[j]){
					//swap elements
					temp = arr[j-1];
					arr[j-1] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	public int linearSearch(int key){
        for(int i=0;i<arr.length;i++){
            if(arr[i] == key){
                return i;
            }
        }
        return -1;
    }

	public void setArr(int[] array) {
		arr = array;
	}
	
	public int[] getArray(){
		return arr;
	}
}
