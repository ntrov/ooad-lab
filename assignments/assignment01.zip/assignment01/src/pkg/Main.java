package pkg;

public class Main {
	public static void main(String[] args) {

		assignment model = new assignment();
		assignmentView view = new assignmentView();
		assignmentController controller = new assignmentController(model, view);
		controller.setArray();
		controller.updateView();
		controller.sortArray();
		controller.updateView();
		controller.searchValue();
	}
}