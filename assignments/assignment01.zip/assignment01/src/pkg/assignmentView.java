package pkg;

import javax.swing.JOptionPane;

public class assignmentView {
	
	public int[] vSetArr() {
		int[] arr = new int[5];
		
		for (int i = 0; i < 5; i++) {
			arr[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter your Number"));
		}
		
		return arr;
	}
	
	public void printArray(int[] array) {
		for(int i = 0; i < 5; i++) {
			System.out.print(array[i] + ", ");
		}
		System.out.print("\n");
	}
	
	public int setKey() {
		return Integer.parseInt(JOptionPane.showInputDialog("Enter The Value to Search"));
	}
	
	public void vSearchValue(int i) {
		if(i == -1) {
			System.out.println("Value Not Found");
		}
		else {
			System.out.println("Value Found at Index " + i);
		}
	}
}
