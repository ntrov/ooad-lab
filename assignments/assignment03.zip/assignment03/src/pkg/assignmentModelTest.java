package pkg;

import static org.junit.Assert.*;

import org.junit.Test;

public class assignmentModelTest {

	@Test
	public void testVerify_email_address1() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("Wajahat.Raza109@yahoo.com");
		
		assertTrue(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address2() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("Wajahat-Raza109@gmail.com");
		
		assertTrue(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address3() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("Wajahat.Raza109@hotmail.com");
		
		assertTrue(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address4() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("Wajahat.Raza109@live.com");
		
		assertTrue(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address5() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("Wajahat.Raza%@live.com");
		
		assertFalse(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address6() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("@live.com");
		
		assertFalse(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address7() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("wajahat@");
		
		assertFalse(model.verify_email_address());
	}
	
	@Test
	public void testVerify_email_address8() {
		assignmentModel model = new assignmentModel();
		
		model.setEmail("@");
		
		assertFalse(model.verify_email_address());
	}

}
