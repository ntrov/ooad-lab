package pkg;

public class assignmentController {
	private assignmentModel model;
	private assignmentView view;
	
	public assignmentController(assignmentModel model, assignmentView view){
		this.model = model;
		this.view = view;
	}
	
	public void enterEmail() {
		model.setEmail(view.vSetEmail());
		view.vResult(model.verify_email_address());
	}
}
