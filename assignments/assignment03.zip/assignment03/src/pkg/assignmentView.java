package pkg;

import javax.swing.JOptionPane;

public class assignmentView {
	public String vSetEmail() {
		String email = JOptionPane.showInputDialog("Enter the email");
		
		return email;
	}
	
	public void vResult(boolean flag) {
		if (flag == false) {
			System.out.println("Enter a Proper Email");
		} else {
			System.out.println("Email Accepted");
		}
	}
}
