package pkg;

public class assignmentModel {
private String email;
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean verify_email_address() {
		boolean flag = true;
		String[] parts = email.split("@");
		
		if (parts.length != 2) {
			return false;
		}
		
		if (parts[0].equals("")) {
			return false;
		}
		
		for(int i = 0; i < parts[0].length(); i++) {
			if ( (((int)parts[0].charAt(i) >= 65) && ((int)parts[0].charAt(i) <= 90)) ||  //a-z
				(((int)parts[0].charAt(i) >= 97) && ((int)parts[0].charAt(i) <= 122)) ||   //A-Z
				((int)parts[0].charAt(i) == 45) || 											//-
				((int)parts[0].charAt(i) == 46) ||											//.
				(((int)parts[0].charAt(i) >= 48) && ((int)parts[0].charAt(i) <= 57)) ) { 	//0-9
				flag = true;
			}
			else {
				flag = false;
				break;
			}
		}
		
		if (flag == true) {
			if ( (parts[1].equals("gmail.com")) || 
				(parts[1].equals("hotmail.com")) || 
				(parts[1].equals("live.com")) || 
				(parts[1].equals("yahoo.com"))) {
				
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	
	}
}
