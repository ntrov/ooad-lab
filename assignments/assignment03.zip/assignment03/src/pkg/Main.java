package pkg;

public class Main {
	public static void main(String[] args) {
		assignmentModel model = new assignmentModel();
		assignmentView view = new assignmentView();
		assignmentController controller = new assignmentController(model, view);

		controller.enterEmail();
	}
}
