package assignment02;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class studentDetails extends JFrame {

	private JPanel contentPane;
	private JTextField searchName;
	private JTable table;
	private JScrollPane scrollPane;
	private connection con;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentDetails frame = new studentDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void fetchinfo() {
		String name = searchName.getText();
		
		ResultSet res = con.getResult(name);
		
		table.setModel(DbUtils.resultSetToTableModel(res));
//		JOptionPane.showMessageDialog(null, "name: " + name);
	}

	/**
	 * Create the frame.
	 */
	public studentDetails() {
		
		con = new connection();
		
		con.connect();
		
		setTitle("Student Record");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(63, 34, 80, 21);
		contentPane.add(lblName);
		
		searchName = new JTextField();
		searchName.setBounds(168, 35, 124, 19);
		contentPane.add(searchName);
		searchName.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fetchinfo();
			}
		});
		btnSearch.setBounds(178, 88, 114, 25);
		contentPane.add(btnSearch);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 151, 473, 245);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
	}
}
