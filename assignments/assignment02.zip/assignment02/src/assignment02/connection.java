package assignment02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class connection {
	private Connection cn;
	
	public void connect() {
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost/ooad","root","");
			JOptionPane.showMessageDialog(null, "Connected");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Could not Connect");
		}
		
	}
	
	public ResultSet getResult(String name) {
		ResultSet res = null;
		
		String query = "SELECT * FROM student WHERE st_name = ? ";
		
		
		PreparedStatement ps;
		try {
			ps = cn.prepareStatement(query);
			ps.setString(1, name);
			res = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

}
